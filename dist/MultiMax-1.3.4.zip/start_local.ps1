$host.UI.RawUI.WindowTitle = 'MultiMax - servidor local'
Write-Host 'Iniciando MultiMax (carregando ambiente e venv)...' -ForegroundColor Green
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$envFile = Join-Path $root '.env.txt'
if (Test-Path $envFile) {
  Write-Host ('Carregando variáveis de: {0}' -f $envFile) -ForegroundColor DarkGray
  Get-Content $envFile | ForEach-Object {
    if ($_ -match '^\s*([^#=\s]+)\s*=\s*(.*)$') {
      $k = $Matches[1]
      $v = $Matches[2]
      if ($v -match '^\s*"(.*)"\s*$') { $v = $Matches[1] }
      Set-Item -Path "Env:$k" -Value $v
    }
  }
}
$activate = Join-Path $root '.venv\\Scripts\\Activate.ps1'
if (Test-Path $activate) { & $activate }
Set-Location $root
$pyVenv = Join-Path $root '.venv\Scripts\python.exe'
$python = if (Test-Path $pyVenv) { $pyVenv } else { 'python' }
Write-Host ('Usando Python: {0}' -f $python) -ForegroundColor DarkGray
$port = [Environment]::GetEnvironmentVariable('PORT')
if (-not $port -or $port -eq '') { $port = '5000' }
Write-Host ('Servidor iniciando em http://localhost:{0}' -f $port) -ForegroundColor Yellow
& $python 'app.py'
